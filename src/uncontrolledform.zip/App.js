import React from 'react';
import logo from './logo.svg';
import './App.css';

class App extends React.Component{
constructor(props){
super(props);

this.state= {account:[],name:'',type:'',region:''}
this.submit =this.submit.bind(this);
this.changehandler1 = this.changehandler1.bind(this);
//this.changehandler2 = this.changehandler2.bind(this);

}
submit(e){
  e.preventDefault();
var acc = this.state.account;
acc.push({name:this.state.name,type:this.state.type,region:this.refs.region.value});
this.setState({account:acc});
console.log(this.state.account);

}
changehandler1(e){
  e.target.name == "name1" ?this.setState({name:e.target.value}):this.setState({type:e.target.value});
  
  //this.setState({name:e.target.value});
}
/*

changehandler2(){

  this.setState({region:this.refs.region.value});
}*/
render(){

  return(<form onSubmit={this.submit}> 

  Account Name : <input type="text" name="name1" value={this.state.name} onChange={this.changehandler1}/><br/>

  Account Type :  <select name="select1" onChange={this.changehandler1}>
    <option value="WholeSale">WholeSale</option>
    <option value="Retail">Retail</option>
    <option value="Banking">Banking</option>
    </select> <br/>
  Account Region :  <input type="text" ref="region" /><br/>
  <button type="submit" >Save</button>
    </form>);

    
  
}
}

export default App;
